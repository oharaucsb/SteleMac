__author__ = 'Sphinx'


"""
Original newhsganalysis dependency lists

import os
import io
import glob
import errno
import copy
import json
import numpy as np
from scipy.optimize import curve_fit
import scipy.interpolate as spi
import scipy.optimize as spo
import scipy.fftpack as fft
import matplotlib.pyplot as plt
import scipy.ndimage as ndimage
import itertools as itt
"""
