__author__ = 'Sphinx'

# TODO: evaluate moving to analysis, it occurs after processing, used in
#   collection functions

from . import full_absorbance
from . import full_high_sideband
from . import full_spectrum
from . import helper_functions
