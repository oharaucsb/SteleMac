__author__ = 'Sphinx'

# TODO: Verify main inheritor is QWP, move into QWP module
