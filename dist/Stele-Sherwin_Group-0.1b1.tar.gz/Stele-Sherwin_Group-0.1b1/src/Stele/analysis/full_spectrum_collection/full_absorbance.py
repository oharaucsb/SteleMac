from .full_spectrum import FullSpectrum


class FullAbsorbance(FullSpectrum):
    """
    I'm imagining this will sew up absorption spectra, but I'm not at all sure
    how to do that at the moment.
    """

    def __init__(self):
        pass
