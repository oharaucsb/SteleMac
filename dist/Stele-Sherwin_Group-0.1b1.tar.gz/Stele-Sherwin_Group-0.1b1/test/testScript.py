import SiOBox.testPack as t

t.testbed.memberTest()
